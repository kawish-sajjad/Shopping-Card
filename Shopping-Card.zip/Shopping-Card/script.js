$(document).ready(function(){

	$('.card').hover(function(){
		$(this).find(".contant").toggle();
	 });
});
